# llm_summit_demos

Run the summit_metadata script (~ 1 minute)

Run the summit_subscriber script (~ 1 minute)

Run the summit_engagement script (~ 10 minutes)

Run the summit_performance_marketing script (~ 1 minute)

Projects -> Streamlit -> + Streamlit App.

Name your App 'Media Cortex Analyst'.
  App Location: 
    Database: LLM_DEMO
    Schema: SUMMIT
    App Warehouse: LLM_DEMO

Create another stage in LLM_DEMO.SUMMIT called YAML_FILES.
  Upload the 3 yaml files here (subscriber, engagement, performance marketing).

Upload the Snowflake_Logo file to the same stage as the Streamlit App.


